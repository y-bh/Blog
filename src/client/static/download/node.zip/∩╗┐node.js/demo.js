// npm install superagent
// npm install superagent-proxy
let request = require('superagent')
require('superagent-proxy')(request)

let targetUrl = 'http://myip.ipip.net'

let proxyServer = '代理IP:代理端口'
let proxyUrl = 'http://' + proxyServer
//账号密码验证
//let proxyUrl = 'http://' + '账号:密码' + '@' + proxyServer

request.get(targetUrl)
    .proxy(proxyUrl)
    .then(res => {
        console.log(res.text)
    }).catch(err => {
        console.log(err.message)
    })